# GwenCrawler
The program is used to download TeacherGwen's articles and parse them and then save them into Youdao Note, to make it easier to collect and review the notes.
